import '../css/dash_container.css'

const dash_container = ({}) =>{
    return(
        <div >
            <div className='contained'>
                <div className='item1'>
                    <h2>Employee Count</h2>
                    <h3>.</h3>
                </div>
                <div className='item2'>
                    <h1>item</h1>
                    
                </div>
                <div className='item3'>
                    <h1>item</h1>
                    
                </div>
            </div>

              <div>  
            <div className='contained2'>
                <div className='item4'>
                            <h1>item</h1>
                            
                        </div>
            </div>
            </div>
        </div>
        
    )
    
}

export default dash_container;
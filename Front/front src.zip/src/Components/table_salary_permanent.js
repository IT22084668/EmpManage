import { Box } from "@mui/material"
import '../css/bootstrap.min.css'
import '../css/table.css'


const Table_salary_permanent = ({}) =>{
    

    return(
        <Box >
           
        <div className="table-possition">
            <table class="table-fill">
            <thead>
            <tr>
            <th class="text-left">Name</th>
            <th class="text-left">NIC</th>
            <th class="text-left">Age</th>
            <th class="text-left">Email</th>
            <th class="text-left">Monthly Salary</th>
            </tr>
            </thead>
            <tbody class="table-hover">
            <tr>
            
            </tr>
            </tbody>
            </table>
  

            </div>
        </Box>
    )
}
export default Table_salary_permanent;